// Configuration
const BACKEND_URL = 'musync-production.up.railway.app'; // Update this with your deployed backend URL
const SYNC_INTERVAL = 3000; // 3 seconds
const DRIFT_TOLERANCE = 0.5; // 0.5 seconds

// Elements
const audio = document.getElementById('pm-audio');
const trackNameEl = document.getElementById('track-name');
const timestampEl = document.getElementById('timestamp');
const playBtn = document.getElementById('play-btn');

// State
let currentTrackId = null;
let syncIntervalId = null;

// Format seconds to MM:SS
function formatTime(seconds) {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

// Main sync function
async function sync() {
  try {
    const response = await fetch(`${BACKEND_URL}/status`);
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    
    const status = await response.json();
    
    // Update track name
    if (trackNameEl) {
      trackNameEl.textContent = `Playing: ${status.track_id}`;
    }
    
    // Update timestamp display
    if (timestampEl) {
      timestampEl.textContent = formatTime(status.timestamp);
    }
    
    // Load new track if changed
    if (currentTrackId !== status.track_id) {
      console.log('Loading new track:', status.track_id);
      currentTrackId = status.track_id;
      audio.src = status.track_url;
      await audio.load();
    }
    
    // Check drift and correct if needed
    const drift = Math.abs(audio.currentTime - status.timestamp);
    
    if (drift > DRIFT_TOLERANCE) {
      console.log(`Correcting drift: ${drift.toFixed(2)}s`);
      audio.currentTime = status.timestamp;
    }
    
    // Handle play/pause state
    if (status.is_playing && audio.paused) {
      console.log('Starting playback');
      try {
        await audio.play();
        if (playBtn) playBtn.style.display = 'none';
      } catch (err) {
        console.warn('Autoplay blocked:', err.message);
        if (playBtn) {
          playBtn.style.display = 'block';
          playBtn.textContent = '▶️ Click to Play';
        }
      }
    } else if (!status.is_playing && !audio.paused) {
      console.log('Pausing playback');
      audio.pause();
    }
    
  } catch (error) {
    console.error('Sync error:', error);
    if (trackNameEl) {
      trackNameEl.textContent = '⚠️ Connection error';
    }
  }
}

// Initialize
async function init() {
  console.log('Personal Mixer initializing...');
  
  // Initial sync
  await sync();
  
  // Start periodic sync
  syncIntervalId = setInterval(sync, SYNC_INTERVAL);
  
  // Handle play button click
  if (playBtn) {
    playBtn.addEventListener('click', async () => {
      if (audio.src) {
        try {
          await audio.play();
          playBtn.style.display = 'none';
          console.log('Playback started by user interaction');
        } catch (err) {
          console.error('Play failed:', err);
          playBtn.textContent = '❌ Play failed';
        }
      }
    });
  }
}

// Start when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

// Cleanup on unload
window.addEventListener('beforeunload', () => {
  if (syncIntervalId) {
    clearInterval(syncIntervalId);
  }
});
